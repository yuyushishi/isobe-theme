<section class="commonAccess">
  <div class="bg">
    <div class="container">
      <div class="wrap">
        <div class="logo">
          <a href="<?php echo esc_url(home_url()); ?>"><img src="<?php echo get_template_directory_uri(); ?>/images/common/logo-03.png" alt="医療法人札幌いそべクリニック"></a>
        </div>
        <ul class="sns">
          <?php $array = [
            1 => ['instaIcon', 'https://www.instagram.com/isobe_staff/'],
            2 => ['facebookIcon', 'https://www.facebook.com/people/%E3%81%84%E3%81%9D%E3%81%B9-%E3%81%A1%E3%81%82%E3%81%8D/100058598261086/'],
            3 => ['youtubeIcon', 'https://www.youtube.com/channel/UC_a8d57j_M3a1NCTaOkl68g'],
            4 => ['lineIcon', 'https://line.me/R/ti/p/%40979kmyvc'],
          ];
          foreach ($array as $key => $value) : ?>
            <li class="snsItem">
              <a href="<?php echo $value[1]; ?>" target="_blank" rel="noopenner">
                <svg viewBox="0 0 512 512">
                  <use xlink:href="<?php echo get_template_directory_uri(); ?>/dist/svg/sprite.svg#<?php echo $value[0]; ?>"></use>
                </svg>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <dl class="list">
        <?php
        $array = [
          '診療科目' => ['脳神経内科・脳神経外科・循環器内科・精神科・リハビリテーション科'],
          '​電話番号' => ['011-753-6000'],
          'FAX番号' => ['011-753-6060'],
          '住所' => ['札幌市東区北36条東15丁目1-20'],
          '​公共機関' => ['地下鉄『東豊線』1番出口を左へ 徒歩1分', '/access/', 'アクセスページへ'],
          '診察受付' => ['（開錠8:15）午前8:15～12:00 午後13:00～16:30'],
          '休診' => ['水曜午後・土曜午後・日曜・祝日'],
        ];
        foreach ($array as $key => $value) : ?>
          <div class="inner">
            <dt><?php echo $key; ?></dt>
            <dd>
              <?php echo $value[0]; ?>
              <?php if (in_array($value[2], $value)) : ?>
                <a href="<?php echo $value[1]; ?>" target="_blank">
                  <svg viewBox="0 0 512 512">
                    <use xlink:href="<?php echo get_template_directory_uri(); ?>/dist/svg/sprite.svg#caretIcon"></use>
                  </svg>
                  <span><?php echo $value[2]; ?></span>
                </a>
              <?php endif; ?>
            </dd>
          </div>
        <?php endforeach; ?>
      </dl>
      <figure class="pic"><img src="<?php echo get_template_directory_uri(); ?>/images/common/calendar.jpg" alt="カレンダー"></figure>
      <p>
        ※1　循環器内科…毎月第１・３火曜日<br>
        ※2　認知症カフェ…2ヶ月毎　14:00〜15:00<br>
        ※3…お薬診察は土曜日をお勧めします　土曜日 9:15〜12:00　矢野医師（内科医）による同様処方（日数調整）外来です。
      </p>
    </div>
  </div>
</section>


<!-- footer -->
<footer id="footer" class="footer">
  <div class="container">
    <nav id="footerNav" class="footerNav">
      <?php
      wp_nav_menu(array(
        'menu' => 'global_navi',
        'menu_class' => 'list',
        'container' => false,
        'add_li_class'  => 'main mainMenu listItem',
      )); ?>
    </nav>
  </div>

  <p class="copy">&copy;2022 ISOBE CLINIC</p>

</footer>
<!-- wrapper -->
</div>

<!-- jQuery -->
<script src="<?php echo get_template_directory_uri(); ?>/dist/js/lib/swiper-bundle.min.js?<?php echo date('YmdHi', filemtime(get_template_directory() . '/dist/js/lib/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo get_template_directory_uri(); ?>/src/js/swiper.js?<?php echo date('YmdHi', filemtime(get_template_directory() . '/src/js/swiper.js')); ?>"></script>
<!-- swiper -->
<script src="<?php echo get_template_directory_uri(); ?>/dist/js/lib/jquery-3.6.0.min.js?<?php echo date('YmdHi', filemtime(get_template_directory() . '/dist/js/lib/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo get_template_directory_uri(); ?>/src/js/function.js?<?php echo date('YmdHi', filemtime(get_template_directory() . '/src/js/function.js')); ?>"></script>
<?php wp_footer(); ?>
</body>

</html>