<?php get_header(); ?>

<section class="contact-direct">
  <div>
    <?php the_content(); ?>
  </div>
</section>

<?php get_footer(); ?>