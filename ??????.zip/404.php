<?php get_header(); ?>

<section>
  <h1>ページが見つかりませんでした。<br><span>404 ERROR</span></h1>
</section>

<?php get_footer(); ?>