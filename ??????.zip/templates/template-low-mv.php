<section class="commonLowMv">
  <span class="en"><?php the_field('サブタイトル'); ?></span>
  <div class="container">
    <h1>
      <span class="jp"><?php the_title(); ?></span>
    </h1>
    <figure class="mv">
      <span><img src="<?php echo get_template_directory_uri(); ?>/images/top/mv.jpg" alt="医療法人札幌いそべクリニック"></span>
    </figure>
  </div>
  <?php output_breadcrumb(); ?>
</section>