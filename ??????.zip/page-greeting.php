<?php get_header(); ?>

<main class="greetingMain">

  <?php include('templates/template-low-mv.php'); ?>

  <section class="greetingDoctor">
    <div class="container">
      <h2 class="c-sectionLowTitle">院長あいさつ</h2>
      <div class="inner">
        <figure class="innerPic"><img src="<?php echo get_template_directory_uri(); ?>/images/greeting/doctor-02.jpg" alt="院長 磯部千明"></figure>
        <div class="bg">
          <p class="innerText">
            <span class="top">当クリニックは、日本で唯一の“頭痛・もの忘れ”をクリニック名とする脳神経内科クリニックです。精神科や神経科または心療内科とは異なります。全身機能を司る脳や神経系は、何らかの原因によって障害されると、頭痛やもの忘れ、めまい、内臓不具合などの症状が出ます。「年のせいだから」「精神的なものだろう」と諦めている人が多いのですが、これは脳・神経系の異常であることが、多々あります。頭痛・首の痛み・めまい・しびれ・ふるえ・動作が遅くなってきた・眠れない‥などは、決して我慢する症状ではありません。早期発見・予防治療ができれば改善することがあり、諦めないことが大切です。「頭痛」、「認知症」・「むずむず脚症候群」・「パーキンソン病」・「脳卒中」・「てんかん」および「疲労」なども増えてきています。当事者のニーズを考え、あなたの悩みを受け止め、応え、そして超える！をモットーにしています。まずは当クリニックまでお気軽にご相談ください。</span>
            <span class="bottom">院長 磯部 千明</span>
          </p>
        </div>
      </div>

      <div class="link">
        <a href="https://isobeclinic.hatenablog.com/" target="_blank" rel="noopnener">
          <img src="<?php echo get_template_directory_uri(); ?>/images/greeting/banner-01.jpg" alt="からだ相談">
        </a>
      </div>
    </div>
  </section>



  <section class="greetingCareer">
    <div class="container">
      <h2 class="c-contentLowTitle">院長経歴</h2>
      <div class="wrap c-contentWidth">
        <p class="text">
          札幌いそべ頭痛・もの忘れクリニック<br>
          理事長・院長 磯部 千明
        </p>
        <dl class="list commonList">
          <?php
          $link_group = SCF::get('career');
          foreach ($link_group as $fields) :
          ?>
            <div class="inner">
              <dt><?php echo esc_html($fields['year']); ?></dt>
              <dd><?php echo esc_html($fields['description']); ?></dd>
            </div>
          <?php endforeach; ?>
        </dl>
      </div>
    </div>
  </section>


  <section class="greetingLicense">
    <div class="container">
      <h2 class="c-contentLowTitle">所属学会・資格</h2>
      <div class="wrap c-contentWidth">
        <ul class="list">
          <?php
          $array = [
            1 => ['所属学会・資格'],
            2 => ['医学博士 学位論文『痴呆性疾患における髄液中アセチルコリンおよびコリン濃度の検討』'],
            3 => ['日本神経学会 脳神経内科専門医・指導医'],
            4 => ['日本頭痛学会 頭痛 専門医・指導医'],
            5 => ['日本認知症学会 認知症 専門医・指導医'],
            6 => ['日本脳卒中学会 脳卒中 専門医'],
            7 => ['日本内科学会 認定内科医'],
            8 => ['日本糖尿病協会 療養指導医'],
            9 => ['身体障害者指定医'],
            10 => ['指定難病認定医'],
            11 => ['臨床研修指導医'],
            12 => ['ボトックス治療免許'],
            13 => ['t-PA治療免許'],
            14 => ['救急救命BLS、ACLS講習 受講医'],
            15 => ['認知症サポート医'],
            16 => ['かかりつけ医認知症対応力向上研修受講医'],
            17 => ['日本脳神経外科学会 会員'],
            18 => ['日本東洋医学会 会員'],
          ];
          foreach ($array as $key => $value) : ?>
            <li class="listItem"><?php echo esc_html($value[0]); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </section>




  <section class="greetingCharge">
    <div class="container">
      <h2 class="c-contentLowTitle">治験担当医(責任医師・分担医師)</h2>
      <div class="wrap c-contentWidth">
        <dl class="list commonList">
          <?php
          $array = [
            '2018年' => ['片頭痛治療薬（抗CGRP受容体作動薬）第II相試験／治験担当医師'],
            '2017年' => ['医学博士 パーキンソン病治療薬（アデノシンA2A受容体拮抗薬）第II相試験／治験担当医師'],
            '2010年' => ['医学博士 パーキンソン病治療薬 エフピー単独治療／治験担当医師'],
            '2007年' => ['医学博士 片頭痛予防薬 トピラマート 第III相試験／治験担当医師'],
            '1999年' => ['医学博士 パーキンソン病治療薬 プラミぺキソール 第III相試験／治験担当医師'],
          ];
          foreach ($array as $key => $value) : ?>
            <div class="inner">
              <dt><?php echo $key ?></dt>
              <dd><?php echo esc_html($value[0]); ?></dd>
            </div>
          <?php endforeach; ?>
        </dl>
      </div>
    </div>
  </section>



  <section class="greetingPerformance">
    <div class="container">
      <h2 class="c-contentLowTitle">実績紹介</h2>
      <ul class="list">
        <?php $array = [
          1 => ['所属学会・資格', ''],
          2 => ['学会発表共同演者', ''],
          3 => ['治験担当医', ''],
          4 => ['演者・司会', ''],
          5 => ['自著の論文・著書', ''],
          6 => ['著書紹介', ''],
          7 => ['累積症例数または患者数', ''],
          8 => ['英語論文', ''],
        ];
        foreach ($array as $key => $value) : ?>
          <li class="listItem">
            <a href="<?php echo $value[1]; ?>">
              <span><?php echo $value[0]; ?></span>
              <svg viewBox="0 0 512 512">
                <use xlink:href="<?php echo get_template_directory_uri(); ?>/dist/svg/sprite.svg#angleIcon"></use>
              </svg>
            </a>
          </li>
        <?php endforeach; ?>
      </ul>

      <div class="box">
        <a href="https://www.isobeclinic.jp/faq" target="_blank" rel="noopenner"><img src="<?php echo get_template_directory_uri(); ?>/images/greeting/banner-02.jpg" alt="doctor'sblog"></a>
        <a href="https://isobeclinic.hatenablog.com/" target="_blank" rel="noopnener"><img src="<?php echo get_template_directory_uri(); ?>/images/greeting/banner-01.jpg" alt="からだ相談"></a>
        <a href="https://isobestaff2.hatenablog.com/" target="_blank" rel="noopenner"><img src="<?php echo get_template_directory_uri(); ?>/images/greeting/banner-03.jpg" alt="いそべスタッフブログ"></a>
      </div>

      <div class="inner">
        <figure class="pic01"><img src="<?php echo get_template_directory_uri(); ?>/images/greeting/picture-01.jpg" alt=""></figure>
        <figure class="pic02"><img src="<?php echo get_template_directory_uri(); ?>/images/greeting/picture-02.jpg" alt=""></figure>
      </div>

    </div>

  </section>

  <?php include('templates/template-map.php'); ?>

</main>
<?php get_footer(); ?>